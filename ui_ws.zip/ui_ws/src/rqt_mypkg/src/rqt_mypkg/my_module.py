import os
import rospy
import rospkg
import time
import traceback, sys

from qt_gui.plugin import Plugin
from python_qt_binding import loadUi
from python_qt_binding.QtWidgets import QWidget
from mavros_msgs.msg import State
from geometry_msgs.msg import PoseStamped, Point, Pose
from sensor_msgs.msg import BatteryState
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from px4_mavros_run import Px4Controller
from commander import Commander

class WorkerSignals(QObject):
    finished = pyqtSignal()
    error = pyqtSignal(tuple)
    result = pyqtSignal(object)
    progress = pyqtSignal(int)

class Worker(QRunnable):
    def __init__(self, fn, *args, **kwargs):
        super(Worker, self).__init__()

        # Store constructor arguments (re-used for processing)
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()

        # Add the callback to our kwargs
        self.kwargs['progress_callback'] = self.signals.progress

    @pyqtSlot()
    def run(self):
        '''
        Initialise the runner function with passed args, kwargs.
        '''

        # Retrieve args/kwargs here; and fire processing using them
        try:
            result = self.fn(*self.args, **self.kwargs)
        except:
            traceback.print_exc()
            exctype, value = sys.exc_info()[:2]
            self.signals.error.emit((exctype, value, traceback.format_exc()))
        else:
            self.signals.result.emit(result)  # Return the result of the processing
        finally:
            self.signals.finished.emit()  # Done

class MyPlugin(Plugin):

    def __init__(self, context, *args, **kwargs):
        super(MyPlugin, self).__init__(context, *args, **kwargs)
        # Give QObjects reasonable names
        self.setObjectName('MyPlugin')

        # Process standalone plugin command-line arguments
        from argparse import ArgumentParser
        parser = ArgumentParser()
        # Add argument(s) to the parser.
        parser.add_argument("-q", "--quiet", action="store_true",
                      dest="quiet",
                      help="Put plugin in silent mode")
        args, unknowns = parser.parse_known_args(context.argv())
        if not args.quiet:
            print 'arguments: ', args
            print 'unknowns: ', unknowns

        # Create QWidget
        self._widget = QWidget()
        # Get path to UI file which should be in the "resource" folder of this package
        ui_file = os.path.join(rospkg.RosPack().get_path('rqt_mypkg'), 'resource', 'MyPlugin.ui')
        # Extend the widget with all attributes and children from UI file
        loadUi(ui_file, self._widget)
        # Give QObjects reasonable names
        self._widget.setObjectName('MyPluginUi')
        # Show _widget.windowTitle on left-top of each plugin (when
        # it's set in _widget). This is useful when you open multiple
        # plugins at once. Also if you open multiple instances of your
        # plugin at once, these lines add number to make it easy to
        # tell from pane to pane.
        if context.serial_number() > 1:
            self._widget.setWindowTitle(self._widget.windowTitle() + (' (%d)' % context.serial_number()))
        # Add widget to the user interface
        context.add_widget(self._widget)

        #Create thread pool
        self.threadpool = QThreadPool()

        # Text Box
        self._widget.X.setText("0")
        self._widget.Y.setText("0")
        self._widget.Z.setText("0")
        self._widget.Yaw.setText("0")
        self._widget.textEdit.setReadOnly(True)

        # Button
        self._widget.Offbaord.clicked.connect(self.Offbaord)
        self._widget.Arm.clicked.connect(self.Arm)
        self._widget.Disarm.clicked.connect(self.Disarm)
        self._widget.Land.clicked.connect(self.Land)
        self._widget.Altitude.clicked.connect(self.Altitude)
        self._widget.Send_XYZ.clicked.connect(self.XYZ)
        self._widget.Send_Yaw.clicked.connect(self.Yaw)

        # Label
        self._widget.Connected.setReadOnly(True)
        self._widget.Armed.setReadOnly(True)
        self._widget.Mode.setReadOnly(True)
        self._widget.Position_X.setReadOnly(True)
        self._widget.Position_Y.setReadOnly(True)
        self._widget.Position_Z.setReadOnly(True)
        self._widget.Battery_Volatge.setReadOnly(True)
        self._widget.Battery_Percentage.setReadOnly(True)

        # Subscriber
        rospy.Subscriber("/mavros/state", State, self.state_callback)
        rospy.Subscriber("/mavros/local_position/pose/", PoseStamped, self.pose_callback)
        rospy.Subscriber("/mavros/battery", BatteryState, self.batt_callback)

        # Services
    def execute_Offbaord(self, progress_callback):
        con = Px4Controller()
        time.sleep(2)
        con.start()
    def execute_Arm(self, progress_callback):
        con = Px4Controller()
        time.sleep(2)
        con.arm()
        time.sleep(2)
    def execute_Disarm(self, progress_callback):
        con = Px4Controller()
        time.sleep(2)
        con.disarm()
        time.sleep(2)
    def execute_Land(self, progress_callback):
        con = Commander()
        time.sleep(2)
        con.land()
        time.sleep(2)
    def execute_Altitude(self, progress_callback):
        con = Px4Controller()
        time.sleep(2)
        con.altitude()
        time.sleep(2)
    def execute_XYZ(self, progress_callback):
        con = Commander()
        time.sleep(2)
        con.move(float(self._widget.X.text()), float(self._widget.Y.text()), float(self._widget.Z.text()))
        time.sleep(2)
        self._widget.X.setText("0")
        self._widget.Y.setText("0")
        self._widget.Z.setText("0")
    def execute_Yaw(self, progress_callback):
        con = Commander()
        time.sleep(2)
        con.turn(float(self._widget.Yaw.text()))
        time.sleep(2)
    def Offbaord(self):
        self._widget.textEdit.append("Offbaord Start")
        worker = Worker(self.execute_Offbaord)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
    def Arm(self):
        self._widget.textEdit.append("Armed")
        worker = Worker(self.execute_Arm)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
    def Disarm(self):
        self._widget.textEdit.append("Disarmed")
        worker = Worker(self.execute_Disarm)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
    def Land(self):
        self._widget.textEdit.append("Land Mode Activated")
        worker = Worker(self.execute_Land)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
    def Altitude(self):
        self._widget.textEdit.append("Altitude Mode Activated")
        worker = Worker(self.execute_Altitude)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
    def XYZ(self):
        self._widget.textEdit.append("Receive New Move Task")
        self._widget.textEdit.append("X=" + self._widget.X.text() + " Y=" + self._widget.Y.text() + " Z=" + self._widget.Z.text())
        worker = Worker(self.execute_XYZ)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
    def Yaw(self):
        self._widget.textEdit.append("Receive New Yaw Task")
        self._widget.textEdit.append("Degree=" + self._widget.Yaw.text())
        worker = Worker(self.execute_Yaw)  # Any other args, kwargs are passed to the run function
        self.threadpool.start(worker)
        
        # Callback
    def state_callback(self, data):
        Connected = str(data.connected)
        self._widget.Connected.setText(Connected)
        Armed = str(data.armed)
        self._widget.Armed.setText(Armed)
        Mode = str(data.mode)
        self._widget.Mode.setText(Mode)
    def pose_callback(self, data):
        Position_X = str(data.pose.position.x)
        self._widget.Position_X.setText(Position_X)
        Position_Y = str(data.pose.position.y)
        self._widget.Position_Y.setText(Position_Y)
        Position_Z = str(data.pose.position.z)
        self._widget.Position_Z.setText(Position_Z)
    def batt_callback(self, data):
        Battery_Volatge = str(data.voltage)
        self._widget.Battery_Volatge.setText(Battery_Volatge)
        Battery_Percentage = str(data.percentage)
        self._widget.Battery_Percentage.setText(Battery_Percentage)

    def shutdown_plugin(self):
        # TODO unregister all publishers here
        pass

    def save_settings(self, plugin_settings, instance_settings):
        # TODO save intrinsic configuration, usually using:
        # instance_settings.set_value(k, v)
        pass

    def restore_settings(self, plugin_settings, instance_settings):
        # TODO restore intrinsic configuration, usually using:
        # v = instance_settings.value(k)
        pass

    #def trigger_configuration(self):
        # Comment in to signal that the plugin has a way to configure
        # This will enable a setting button (gear icon) in each dock widget title bar
        # Usually used to open a modal configuration dialog